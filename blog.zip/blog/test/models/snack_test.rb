require 'test_helper'

class SnackTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
